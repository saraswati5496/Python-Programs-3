#Code to import excel sheet data into oracle database(in existing already created table)

import pandas as pd
import cx_Oracle

#connection to Oracle database
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1') #CRDEV
cursor = conn.cursor()

table_name = "emp"
excel_file = r'C:\Users\saikiran.kurmapu\OneDrive - Argo Group\W_ALL\Python\export.xlsx'

# Read Excel file into a pandas DataFrame
df = pd.read_excel(excel_file)

# Delete existing data from the table
delete_query = f"DELETE FROM {table_name}"
cursor.execute(delete_query)

# Insert the new data into the Oracle table
for row in df.itertuples(index=False):
   sql = f"INSERT INTO {table_name} VALUES ({','.join([':' + str(i+1) for i in range(len(row))])})"
   cursor.execute(sql, row)

# Commit the data insertion
conn.commit()

# Close the cursor and connection
cursor.close()
conn.close()
